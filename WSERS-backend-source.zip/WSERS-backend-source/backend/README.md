# WSERS Backend Source Code

This folder contains Node.js ES-module (`.mjs`) source files for the six WSERS Lambda functions.

## Lambda function mapping

| AWS Lambda function | Source file |
|---|---|
| `WSERS-CreateEmergencyAlert` | `CreateEmergencyAlert/index.mjs` |
| `WSERS-AddEmergencyContact` | `AddEmergencyContact/index.mjs` |
| `WSERS-UpdateEmergencyContact` | `UpdateEmergencyContact/index.mjs` |
| `WSERS-GetEmergencyContacts` | `GetEmergencyContacts/index.mjs` |
| `WSERS-DeleteEmergencyContact` | `DeleteEmergencyContact/index.mjs` |
| `WSERS-GetEmergencyAlerts` | `GetEmergencyAlerts/index.mjs` |

## Important accuracy note

The Create Emergency Alert implementation below follows the known WSERS implementation and configuration. The other handlers are reconstructed to fit the project details available: API Gateway REST Lambda proxy events, Cognito authorizer claims, DynamoDB table `WSERS`, and keys `PK = USER#<authenticated-email>` plus `SK = CONTACT#<contactId>` or `ALERT#<timestamp>#<alertId>`.

I could not verify every handler against the currently deployed Lambda editor or your complete frontend request payloads. In particular, Update/Delete expect `contactId` in the JSON request body. Before treating this as an exact backup of deployed code, compare each file with the code currently in AWS Lambda and test it. Do not overwrite working deployed functions just to add these files to GitHub.

## Configuration and security

- Region: `us-east-1`
- DynamoDB table: `WSERS`
- SNS topic: `arn:aws:sns:us-east-1:048364826592:WSERS-Emergency-Notifications`
- Each Lambda should use the existing `LabRole` in the AWS Academy lab.
- AWS SDK v3 packages used: `@aws-sdk/client-dynamodb`, `@aws-sdk/lib-dynamodb`, `@aws-sdk/client-sns` (SNS package only for CreateEmergencyAlert).
- Never commit AWS access keys, session tokens, passwords, or private credentials.
- GitHub Pages hosts the frontend only; committing this folder does not deploy Lambda functions.

## Common response and identity behaviour

Handlers expect API Gateway REST API Lambda proxy events with Cognito claims at `event.requestContext.authorizer.claims`. The user identity is taken from the authenticated `email` claim, falling back to `cognito:username`; browser-supplied `userId` is not trusted.
