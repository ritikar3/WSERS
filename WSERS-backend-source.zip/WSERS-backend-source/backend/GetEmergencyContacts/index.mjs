import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { QueryCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const dynamodb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const TABLE_NAME = "WSERS";
const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event));
  try {
    const claims = event.requestContext?.authorizer?.claims;
    const userId = claims?.email || claims?.["cognito:username"];
    if (!userId) return { statusCode: 401, headers, body: JSON.stringify({ success: false, message: "Authentication required." }) };
    const result = await dynamodb.send(new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :prefix)",
      ExpressionAttributeValues: { ":pk": `USER#${userId}`, ":prefix": "CONTACT#" }
    }));
    const contacts = result.Items || [];
    return { statusCode: 200, headers, body: JSON.stringify({ success: true, contacts }) };
  } catch (error) {
    console.error("Error retrieving emergency contacts:", error);
    return { statusCode: 500, headers, body: JSON.stringify({ success: false, message: "Failed to retrieve emergency contacts.", error: error.message }) };
  }
};
