import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { UpdateCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const dynamodb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const TABLE_NAME = "WSERS";
const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event));
  try {
    const claims = event.requestContext?.authorizer?.claims;
    const userId = claims?.email || claims?.["cognito:username"];
    if (!userId) return { statusCode: 401, headers, body: JSON.stringify({ success: false, message: "Authentication required." }) };
    const body = typeof event.body === "string" ? JSON.parse(event.body) : (event.body || {});
    const contactId = body.contactId || event.pathParameters?.contactId;
    if (!contactId) return { statusCode: 400, headers, body: JSON.stringify({ success: false, message: "contactId is required." }) };
    const name = String(body.name || "").trim();
    const phone = String(body.phone || "").trim();
    const email = String(body.email || "").trim();
    if (!name || !phone) return { statusCode: 400, headers, body: JSON.stringify({ success: false, message: "Name and phone are required." }) };

    const result = await dynamodb.send(new UpdateCommand({
      TableName: TABLE_NAME,
      Key: { PK: `USER#${userId}`, SK: `CONTACT#${contactId}` },
      UpdateExpression: "SET #name = :name, #phone = :phone, #email = :email, updatedAt = :updatedAt",
      ConditionExpression: "attribute_exists(PK) AND attribute_exists(SK)",
      ExpressionAttributeNames: { "#name": "name", "#phone": "phone", "#email": "email" },
      ExpressionAttributeValues: { ":name": name, ":phone": phone, ":email": email, ":updatedAt": new Date().toISOString() },
      ReturnValues: "ALL_NEW"
    }));
    return { statusCode: 200, headers, body: JSON.stringify({ success: true, message: "Emergency contact updated successfully.", contact: result.Attributes }) };
  } catch (error) {
    console.error("Error updating emergency contact:", error);
    const notFound = error.name === "ConditionalCheckFailedException";
    return { statusCode: notFound ? 404 : 500, headers, body: JSON.stringify({ success: false, message: notFound ? "Emergency contact not found." : "Failed to update emergency contact.", error: error.message }) };
  }
};
