import { randomUUID } from "node:crypto";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const dynamodb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const TABLE_NAME = "WSERS";
const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event));
  try {
    const claims = event.requestContext?.authorizer?.claims;
    const userId = claims?.email || claims?.["cognito:username"];
    if (!userId) return { statusCode: 401, headers, body: JSON.stringify({ success: false, message: "Authentication required." }) };
    const body = typeof event.body === "string" ? JSON.parse(event.body) : (event.body || {});
    const name = String(body.name || "").trim();
    const phone = String(body.phone || "").trim();
    const email = String(body.email || "").trim();
    if (!name || !phone) return { statusCode: 400, headers, body: JSON.stringify({ success: false, message: "Name and phone are required." }) };

    const timestamp = new Date().toISOString();
    const contact = {
      PK: `USER#${userId}`,
      SK: `CONTACT#${randomUUID()}`,
      contactId: randomUUID(),
      userId,
      name,
      phone,
      email,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    // Keep contactId and SK aligned so a contact can be addressed by CONTACT#<contactId>.
    contact.SK = `CONTACT#${contact.contactId}`;
    await dynamodb.send(new PutCommand({ TableName: TABLE_NAME, Item: contact }));
    return { statusCode: 201, headers, body: JSON.stringify({ success: true, message: "Emergency contact added successfully.", contact }) };
  } catch (error) {
    console.error("Error adding emergency contact:", error);
    return { statusCode: 500, headers, body: JSON.stringify({ success: false, message: "Failed to add emergency contact.", error: error.message }) };
  }
};
