import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DeleteCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const dynamodb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const TABLE_NAME = "WSERS";
const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event));
  try {
    const claims = event.requestContext?.authorizer?.claims;
    const userId = claims?.email || claims?.["cognito:username"];
    if (!userId) return { statusCode: 401, headers, body: JSON.stringify({ success: false, message: "Authentication required." }) };
    const body = typeof event.body === "string" ? JSON.parse(event.body) : (event.body || {});
    const contactId = body.contactId || event.pathParameters?.contactId;
    if (!contactId) return { statusCode: 400, headers, body: JSON.stringify({ success: false, message: "contactId is required." }) };
    await dynamodb.send(new DeleteCommand({
      TableName: TABLE_NAME,
      Key: { PK: `USER#${userId}`, SK: `CONTACT#${contactId}` },
      ConditionExpression: "attribute_exists(PK) AND attribute_exists(SK)"
    }));
    return { statusCode: 200, headers, body: JSON.stringify({ success: true, message: "Emergency contact deleted successfully.", contactId }) };
  } catch (error) {
    console.error("Error deleting emergency contact:", error);
    const notFound = error.name === "ConditionalCheckFailedException";
    return { statusCode: notFound ? 404 : 500, headers, body: JSON.stringify({ success: false, message: notFound ? "Emergency contact not found." : "Failed to delete emergency contact.", error: error.message }) };
  }
};
