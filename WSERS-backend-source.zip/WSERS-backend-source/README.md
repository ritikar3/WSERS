# WSERS backend source package

Open the `backend` folder for the six Node.js Lambda source files.

**Before use:** this is a source archive, not an AWS deployment package. `CreateEmergencyAlert` follows the known project code/configuration; the remaining handlers were reconstructed from the project architecture and known table/key conventions because their complete deployed source bodies were not available in the conversation context. Compare them with your live Lambda code and test them before deployment. Do not replace working AWS functions without checking.

To upload to the existing GitHub repository, extract the ZIP and upload the `backend` folder (including its subfolders) to the repository's `main` branch. Keep existing frontend files and the `stable-working-version` branch unchanged. GitHub Pages will continue to serve the frontend; it does not run Lambda source code.
